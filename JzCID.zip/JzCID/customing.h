#include <string>
#include "corefunc.h"
#define byte uint8_t
#define BYTE uint8_t

//Customing GrowID
string Growid_acc = "";

//Custome Password By JzuvGTI
string Pass_acc = "";

//Urutan Nomer ID
int Urutan_ID = 1;
